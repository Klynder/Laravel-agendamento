<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Agenda extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'agenda';

    protected $primaryKey = 'id_agenda';

    //protected $timestamps = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [// no atributo fillable, são colocadas todas colunas da tabela associada à classe, exceto a chave primária, a saber, id_grupo
        'id_usuario',
        'hora',
        'dia_da_semana',

    ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */


    public function usuario()
    {
        return $this->belongsTo(User::class, 'id_usuario', 'id_usuario');
    }

    public function agendamento()
    {
        return $this->hasMany(Agendamento::class, foreignKey: 'id_agenda', localKey: 'id_agenda');
    }



}
