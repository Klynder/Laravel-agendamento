<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Agendamento extends Model
{
    use HasFactory;

    protected $table = 'agendamento';
 
    public $timestamps = false;

    protected $primaryKey = 'id_agendamento';

    protected $guarded = ["id_agendamento"];

    protected $fillable = [
        "data",
        "hora",
        "id_cliente",//foreign key
        "id_barbeiro",//foreign key
        "id_servico",//foreign key
        "status",
        "id_agenda"
        
    ];

    public function cliente()
    {
        return $this->belongTo(Client::class, "id_cliente", "id_cliente");
    }

    public function usuario()
    {
        return $this->hasMany(User::class, 'id_grupo', 'id_grupo');
    }

    public function gruposMenus() : BelongsToMany
    {
        return $this->belongsToMany(GrupoMenu::class);
    }
}
