<?php

namespace App\Http\Controllers;

use App\Models\Agendamento;


class AgendamentoController extends Controller
{
    public function getAgendamento(): void
    {
        $agendamentos = Agendamento::get();
    }

}
