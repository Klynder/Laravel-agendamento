<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Grupo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;

class AgendaController extends Controller
{
    public function listarUsuarios(){
        return 'lista de usuários';
    }

    public function createUsuario(Request $request){
        $usuario = User::create([
            'nome_usuario' => $request->nome_usaurio,
            'data_nascimento' => $request->data_nascimento,
            'id_grupo' => $request->id_grupo,
        ]);
        return response()->json($usuario);

    }   
        
    public function getUsuarios(){
        $usuarios = User::all();
        return response()->json($usuarios);

      
    } 

    public fuction getUsuarios(){
        $usuario = User::all();
        return response()->json($usuario);
    }
    

   public function criarAgenda(Request $request)
   {
      $inicio = strtotime($request->horario_nicio)
      $final =strtotime($request->horario_final)
      $intervalo = ($final - $inicio) /60
      $qnt = $intervalo/30;
      for($i=0, $,qnt; $++){
          echo "<br>"  .date("H:i", $inicio),
           agenda::create([
            'horario' -> date(date"H:i", $inicio),
            'id_usuario' -> $request->id_usuario,
            'dia_da_semana' -> $request->dia_a_semana,
    ]);

    $inicio += 1800;
}


}