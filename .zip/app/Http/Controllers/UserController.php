<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Grupo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;

class UserController extends Controller
{
    public function listarUsuarios(){
        return 'lista de usuários';
    }

    public function createUsuario(Request $request){
        $usuario = User::create([
            'nome_usuario' => $request->nome_usaurio,
            'data_nascimento' => $request->data_nascimento,
            'id_grupo' => $request->id_grupo,
        ]);
        return response()->json($usuario);

    }   
        
    public function getUsuarios(){
        $usuarios = User::with('grupo')->get();
        return response()->json(['usuarios' => $usuarios]);

    }       
}