<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Servico;
use App\Models\Grupo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Session;

class ServicoController extends Controller
{
    public function listarServico(){
        return response()->json([
            'servicos'=>Servico::all()
        ]);
    }

    public function createServico(Request $request){
        $usuario = Servico::create([
            'nome_servicos' => $request->nome_usaurio,
            'valor_servicos' => $request->data_nascimento,
            
        ]);
        return response()->json($usuario);

    }   
        
    public function getServico(){
        $usuarios = User::all();
        return response()->json($usuarios);

    }       
}