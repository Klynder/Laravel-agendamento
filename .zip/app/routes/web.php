<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\AgendamentoController;



Route::get('servicos', [ServicoController::class, 'getServico']);
Route::get('usuarios', [UserController::class, 'getUsuarios']);
Route::get('agendamento', [AgendamentoController::class, 'getAgendamento']);
Route::get('criar-usuarios', [UserController::class, 'criarUsuarios']);
Route::get('criar-servicos', [ServicoController::class, 'criarServicos']);
Route::get('criar-agendamento', [AgendamentoController::class, 'criarAgendamentos']);