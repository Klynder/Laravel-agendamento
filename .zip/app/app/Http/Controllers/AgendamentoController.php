<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use App\Models\Agendamento;

class AgendamentoController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function getAgendamento(){
        $agendamento = [
            ['id_agendamento' => 1, 'data' => "10/04/2025", 'hora' => "18:00", 'nome_cliente' => "Kauan Coelho", 'nome_profissional' => "Deus da Umidade"],
            ['id_agendamento' => 1, 'data' => "15/10/2025", 'hora' => "14:30", 'nome_cliente' => "José Albedo", 'nome_profissional' => "Germano SIlva"],
            ['id_agendamento' => 1, 'data' => "30/04/2025", 'hora' => "14:30", 'nome_cliente' => "Alavares Dimundo", 'nome_profissional' => "Germano SIlva"],
            ['id_agendamento' => 1, 'data' => "25/05/2025", 'hora' => "14:00", 'nome_cliente' => "Ivo Antonio", 'nome_profissional' => "Deus da Umidade"],
            ['id_agendamento' => 1, 'data' => "02/08/2025", 'hora' => "15:30", 'nome_cliente' => "Roberto Carlos", 'nome_profissional' => "Deus da Umidade"],
            ['id_agendamento' => 1, 'data' => "03/07/2025", 'hora' => "11:30", 'nome_cliente' => "Emerson Jefferson", 'nome_profissional' => "Deus da Umidade"],
            ['id_agendamento' => 1, 'data' => "20/06/2025", 'hora' => "10:00", 'nome_cliente' => "Pedro Marco", 'nome_profissional' => "Germano SIlva"],
            ['id_agendamento' => 1, 'data' => "31/05/2025", 'hora' => "08:00", 'nome_cliente' => "Pedro Alvares Cabralis", 'nome_profissional' => "Deus da Umidade"],
        ];
        return response()->json($agendamento);
    }
}