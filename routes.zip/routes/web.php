<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ServicoController;





Route::get('', [UserController::class, 'index']);
Route::get('usuarios', [UserController::class, 'getUsuarios']);
Route::get('servicos', [ServicoController::class, 'getServico']);
