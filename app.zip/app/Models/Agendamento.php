<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Agendamento extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $table = 'agendamentos';

    protected $primaryKey = 'id_agendamento';

    //protected $timestamps = false;
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [// no atributo fillable, são colocadas todas colunas da tabela associada à classe, exceto a chave primária, a saber, id_grupo
        'data',
        'id_agenda', // foreignkey
        'id_servico', // foreignkey
        'id_usuario', // foreignkey
    ];


    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */


    public function agenda()
    {
        return $this->belongsTo(Agenda::class, 'id_agenda', 'id_agenda');
    }

    public function servico()
    {
        return $this->belongsTo(Servico::class, foreignKey: 'id_servico', ownerKey: 'id_servico');
    }

    public function usuario()
    {
        return $this->belongsTo(User::class, 'id_usuario', 'id_usuario');
    }


}
