<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class Profissional extends User
{

    protected $table = 'profissionais';
    protected $primaryKey = 'id_profissional';

    protected $fillable = [
        'nome',
        'email',
        'telefone',
        'especialidade',
        'id_setor',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function setor()
    {
        return $this->belongsTo(Setor::class, 'id_setor', 'id_setor');
    }

    public function atendimentos()
    {
        return $this->hasMany(Atendimento::class, 'id_profissional', 'id_profissional');
    }

    public function getNomeSetorAttribute()
    {
        return $this->setor->nome_setor ?? null;
    }
}
